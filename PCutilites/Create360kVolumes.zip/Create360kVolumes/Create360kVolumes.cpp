// Create360kVolumes.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Dennis D Hatton Sr

// Visual C++, Change project properties Charcter Set "not set"

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS	//Disable deprecation warnings
#endif
#include<stdio.h>
#include<conio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[])
{
	char filename[13] = { 0 };
	char strbuffer[25] = { 0 };
	char volnum[4] = { 0 };
	char blanksector[513] = { };

	unsigned int i, k;
	FILE* fp;

	for (i = 0; i < 512; i++) blanksector[i] = 0xE5;
	blanksector[512] = 0;

	printf("Standby creating volumes ");
	for (k = 0; k < 256; k++)	//256
	{
		printf(".");
		strcpy(filename, "TIVOL00");		//Create DOS name
		_itoa(k, volnum, 10);				//Add disk number
		memset(strbuffer, '\0', 25);		//Pad with null, strncpy doesn't null terminate
		strncpy(strbuffer, filename, (8 - strlen(volnum)));
		strcat(strbuffer, volnum);
		strcpy(filename, strbuffer);

		strcat(strbuffer, "  ");			//Pad TI name with spaces
		strcat(filename, ".dsk");			//Add extension DOS name

		fp = fopen(filename, "wb");
		//(Enter disk size below) 90k=(1,0x68) 180k=(2,0xD0) 360k=(5,0xA0)
		fprintf(fp, "%s%c%c%c%s%c%c%c%c", strbuffer, 5, 0xA0, 9, "DSK", 32, 80, 2, 1);
		for (i = 0; i < 36; i++) fprintf(fp, "%c", 0);
		fprintf(fp, "%c", 3);
		for (i = 0; i < 179; i++) fprintf(fp, "%c", 0);				//Free sectors 180k=89 360k=179
		for (i = 0; i < 20; i++) fprintf(fp, "%c", 0xFF);			//Used sectors 180k=110 360k=20
		for (i = 0; i < 256; i++) fprintf(fp, "%c", 0);

		//(Set reserve space size below) 90k=358 180k=718 360k=1438
		for (i = 0; i <= 718; i++) fprintf(fp, "%s", blanksector);

		fclose(fp);
	}
	printf("\nPress any key to continue...\n");
	getchar();	//pause for key
	return 0;
}