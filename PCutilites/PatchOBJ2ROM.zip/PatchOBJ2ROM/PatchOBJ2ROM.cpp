// PatchOBJ2ROM.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Dennis D Hatton Sr
// Only works with absolute tags 0,9,B,7,8
// Visual C++, Change project properties Charcter Set "not set"

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS	//Disable deprecation warnings
#endif
#include <stdio.h>
#include <string.h>
#include <windows.h>		//Also enable Microsoft extensions


BOOL OpenFileDialogInfile(char*);
BOOL OpenFileDialogOutfile(char*);
unsigned int hex2int(unsigned char* buffer, int index, int length);

int main(int argc, char* argv[])
{
	FILE* infile;
	FILE* outfile;
	unsigned int i, j, checksum, cnt, bufferix, loadix;
	unsigned int loadadr[6][2];
	unsigned char Inbuffer[256] = { 0 };
	unsigned char Outbuffer[256] = { 0 };
	char infilename[MAX_PATH] = { 0 };
	char outfilename[MAX_PATH] = { 0 };
	unsigned char* ptr;

	printf("Loads TI object file into DSR ROM file\n");
	printf("by Dennis Hatton 2021 \n\n");

	OpenFileDialogInfile(infilename);
	if ((infile = fopen(infilename, "r")) == NULL)
	{
		printf("Could not open file: %s\n", infilename);
		exit(1);
	}
	OpenFileDialogOutfile(outfilename);
	if ((outfile = fopen(outfilename, "rb+")) == NULL) //Opens existing file for both reading and writing
	{
		printf("Could not open file: %s\n", outfilename);
		exit(1);
	}

	while (!feof(infile))
	{
		fgets((char*)Inbuffer, 256, infile);
		if (Inbuffer[0] == ':') break;

		for (i = 0; i < 6; i++)
		{
			loadadr[i][0] = 0;
			loadadr[i][1] = 0;
		}
		checksum = 0;
		j = 0;
		cnt = 0;
		bufferix = 0;
		loadix = 0;

		while (Inbuffer[j] != '7' && Inbuffer[j] != '8')
		{
			for (i = 0; i < 5; i++)
			{
				checksum = checksum + Inbuffer[j + i];
			}
			if (Inbuffer[j] == '9')
			{
				loadadr[loadix][0] = hex2int(Inbuffer, j + 1, 4);
				if (loadix != 0)
				{
					loadadr[loadix - 1][1] = cnt;
					cnt = 0;
				}
				loadix++;
			}
			if (Inbuffer[j] == 'B')
			{
				Outbuffer[bufferix] = hex2int(Inbuffer, j + 1, 2);
				Outbuffer[bufferix + 1] = hex2int(Inbuffer, j + 3, 2);
				bufferix = bufferix + 2;
				cnt = cnt + 2;
			}
			if (Inbuffer[j] == '0')
			{
				j = j + 8; //skip 8 spaces to next tag
				checksum = checksum + 256; // Add 8 * ' ' to checksum
			}
			j = j + 5;
			if (j >= 256)
			{
				printf("buffer overrun!");
				exit(1);
			}
		}
		if (Inbuffer[j] == '7')
		{
			checksum = checksum + '7';
			checksum = (0 - checksum) & 0xFFFF;
			if (checksum != hex2int(Inbuffer, j + 1, 4))
			{
				printf("checksum error! \n");
				exit(1);
			}
		}
		//Process line in Inbuffer to rom file
		if (loadix != 0)loadadr[loadix - 1][1] = cnt;
		ptr = Outbuffer;

		for (j = 0; j < 6; j++)
		{
			if (loadadr[j][1] == 0)break;
			printf("%04X = ", loadadr[j][0]);
			for (i = 0; i < loadadr[j][1]; i = i + 2) printf("%02X%02X ", ptr[i], ptr[i + 1]);
			printf("\n");
			fseek(outfile, (loadadr[j][0] & 0x1FFF), SEEK_SET);
			fwrite(ptr, 1, loadadr[j][1], outfile);
			ptr = ptr + loadadr[j][1];
		}
	}
	fclose(infile);
	fclose(outfile);
	printf("\nFile finished.\n");
	printf("\nPress any key to continue...\n");
	getchar();	//pause for key
	return 0;
}


/****************************************************************************/
BOOL OpenFileDialogInfile(char* file)	//Function that will call dialog
{
	OPENFILENAME OpenFileName;
	char szFile[MAX_PATH];
	char CurrentDir[MAX_PATH];

	szFile[0] = 0;
	GetCurrentDirectory(MAX_PATH, CurrentDir);

	OpenFileName.lStructSize = sizeof(OPENFILENAME);
	OpenFileName.hwndOwner = NULL;
	OpenFileName.lpstrFilter = "TI OBJ Files\0*.obj\0All Files\0*.*\0";
	OpenFileName.lpstrCustomFilter = NULL;
	OpenFileName.nMaxCustFilter = 0;
	OpenFileName.nFilterIndex = 0;
	OpenFileName.lpstrFile = szFile;
	OpenFileName.nMaxFile = sizeof(szFile);
	OpenFileName.lpstrFileTitle = NULL;
	OpenFileName.nMaxFileTitle = 0;
	OpenFileName.lpstrInitialDir = CurrentDir;
	OpenFileName.lpstrTitle = "SELECT TI OBJECT FILE";
	OpenFileName.nFileOffset = 0;
	OpenFileName.nFileExtension = 0;
	OpenFileName.lpstrDefExt = NULL;
	OpenFileName.lCustData = 0;
	OpenFileName.lpfnHook = NULL;
	OpenFileName.lpTemplateName = NULL;
	OpenFileName.Flags = OFN_EXPLORER;

	if (GetOpenFileName(&OpenFileName))
	{
		strcpy(file, szFile);
		return TRUE;
	}
	else
		return FALSE;
}
/****************************************************************************/
BOOL OpenFileDialogOutfile(char* file)	//Function that will call dialog
{
	OPENFILENAME OpenFileName;
	char szFile[MAX_PATH];
	char CurrentDir[MAX_PATH];

	szFile[0] = 0;
	GetCurrentDirectory(MAX_PATH, CurrentDir);

	OpenFileName.lStructSize = sizeof(OPENFILENAME);
	OpenFileName.hwndOwner = NULL;
	OpenFileName.lpstrFilter = "TI BIN Files\0*.bin\0All Files\0*.*\0";
	OpenFileName.lpstrCustomFilter = NULL;
	OpenFileName.nMaxCustFilter = 0;
	OpenFileName.nFilterIndex = 0;
	OpenFileName.lpstrFile = szFile;
	OpenFileName.nMaxFile = sizeof(szFile);
	OpenFileName.lpstrFileTitle = NULL;
	OpenFileName.nMaxFileTitle = 0;
	OpenFileName.lpstrInitialDir = CurrentDir;
	OpenFileName.lpstrTitle = "SELECT TI ROM BIN FILE";
	OpenFileName.nFileOffset = 0;
	OpenFileName.nFileExtension = 0;
	OpenFileName.lpstrDefExt = NULL;
	OpenFileName.lCustData = 0;
	OpenFileName.lpfnHook = NULL;
	OpenFileName.lpTemplateName = NULL;
	OpenFileName.Flags = OFN_EXPLORER;

	if (GetOpenFileName(&OpenFileName))
	{
		strcpy(file, szFile);
		return TRUE;
	}
	else
		return FALSE;
}


// Converts lenght hex characters to int
// No validation check
unsigned int hex2int(unsigned char* buffer, int index, int length)
{
	unsigned int a, b = 0;

	for (int i = 0; i < length; i++)
	{
		b = (b << 4);
		a = buffer[index + i];
		if (a <= '9') a = a - '0';
		else a = (a & 0x7) + 9;
		b = b + a;
	}
	return b;
}