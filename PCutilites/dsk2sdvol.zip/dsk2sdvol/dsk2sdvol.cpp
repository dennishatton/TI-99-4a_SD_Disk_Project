// dsk2sdvol.cpp : This file contains the 'main' function. Program execution begin
// Dennis D Hatton Sr
// Visual C++, Change project properties Charcter Set "not set"

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS	//Disable deprecation warnings
#endif
#include <stdio.h>
#include <string.h>
#include <windows.h>		//Also enable Microsoft extensions
BOOL OpenInputFileDialog(char*);
BOOL OpenOutputFileDialog(char*);

int main(int argc, char* argv[])
{
	FILE* infile;
	FILE* outfile;
	int rtncode = 0;
	unsigned int i, len;
	unsigned char c;
	unsigned char buffer[256] = { 0 };
	char infilename[MAX_PATH] = { 0 };
	char outfilename[MAX_PATH] = { 0 };
#define tmppath "c:\\temp"
#define tmpdisk "\\DISK.tmp " //leave space at end
	char copycmdstr[256] = { "copy " tmppath tmpdisk " \"" };

	printf("Copies DSK image file to Volume on SD card\n");
	printf("by Dennis Hatton 2020 \n\n");

	OpenInputFileDialog(infilename);
	if ((infile = fopen(infilename, "rb")) == NULL) //rb read binary
	{
		printf("File not found: %s\n", infilename);
		rtncode = 1;
	}
	else {
		fread(buffer, 1, 256, infile);				//binary use fread & frwite
		if (buffer[13] != 'D' || buffer[14] != 'S' || buffer[15] != 'K')
		{
			printf("File is not supported");
			rtncode = 1;
		}
		else {
			len = buffer[10] * 256;		//Size of disk (in sectors)
			len = buffer[11] + len;
			if (len != 0x168 && len != 0x2D0 && len != 0x5A0)
			{
				printf("Only disk size 90k or 180k or 360k supported");
				rtncode = 1;
			}
			else {
				OpenOutputFileDialog(outfilename);
				system("if not exist " tmppath " md " tmppath);
				outfile = fopen(tmppath tmpdisk, "wb");

				fwrite(buffer, 1, 256, outfile);
				for (i = 0; i < (len - 1); i++)	//Sector 0 already done
				{
					fread(buffer, 1, 256, infile);
					fwrite(buffer, 1, 256, outfile);
				}
				len = 0x5A0 - len;	//Pad to 360k
				if (len)
				{
					for (i = 0; i < (len * 256); i++)
					{
						fprintf(outfile, "%c", 0);
					}
				}
				fclose(outfile);

				strcat(copycmdstr, outfilename);
				strcat(copycmdstr, "\"");
				system(copycmdstr);
//				printf("%s", copycmdstr);
				system("del " tmppath tmpdisk);

			}
		}
	}
	fclose(infile);
//	if (rtncode)
//	{
		printf("\nPress any key to continue...\n");
		getchar();	//pause for key
//	}
	return rtncode;
}


/****************************************************************************/


BOOL OpenInputFileDialog(char* file)	//Function that will call dialog
{
	OPENFILENAME OpenFileName;
	char szFile[MAX_PATH];
	char CurrentDir[MAX_PATH];

	szFile[0] = 0;
	GetCurrentDirectory(MAX_PATH, CurrentDir);

	OpenFileName.lStructSize = sizeof(OPENFILENAME);
	OpenFileName.hwndOwner = NULL;
	OpenFileName.lpstrFilter = "DSK Files\0*.dsk\0 TIDisk Files\0*TIDisk\0 All Files\0*.*\0";
	OpenFileName.lpstrCustomFilter = NULL;
	OpenFileName.nMaxCustFilter = 0;
	OpenFileName.nFilterIndex = 0;
	OpenFileName.lpstrFile = szFile;
	OpenFileName.nMaxFile = sizeof(szFile);
	OpenFileName.lpstrFileTitle = NULL;
	OpenFileName.nMaxFileTitle = 0;
	OpenFileName.lpstrInitialDir = CurrentDir;
	OpenFileName.lpstrTitle = "*****  SELECT SOURCE *.DSK FILE  *****";
	OpenFileName.nFileOffset = 0;
	OpenFileName.nFileExtension = 0;
	OpenFileName.lpstrDefExt = NULL;
	OpenFileName.lCustData = 0;
	OpenFileName.lpfnHook = NULL;
	OpenFileName.lpTemplateName = NULL;
	OpenFileName.Flags = OFN_EXPLORER;

	if (GetOpenFileName(&OpenFileName))
	{
		strcpy(file, szFile);
		return TRUE;
	}
	else
		return FALSE;
}

BOOL OpenOutputFileDialog(char* file)	//Function that will call dialog
{
	OPENFILENAME OpenFileName;
	char szFile[MAX_PATH];
	char CurrentDir[MAX_PATH];

	szFile[0] = 0;
	GetCurrentDirectory(MAX_PATH, CurrentDir);

	OpenFileName.lStructSize = sizeof(OPENFILENAME);
	OpenFileName.hwndOwner = NULL;
	OpenFileName.lpstrFilter = "TI Volume Files\0TIVOL*.dsk\0 All Files\0*.*\0";
	OpenFileName.lpstrCustomFilter = NULL;
	OpenFileName.nMaxCustFilter = 0;
	OpenFileName.nFilterIndex = 0;
	OpenFileName.lpstrFile = szFile;
	OpenFileName.nMaxFile = sizeof(szFile);
	OpenFileName.lpstrFileTitle = NULL;
	OpenFileName.nMaxFileTitle = 0;
	OpenFileName.lpstrInitialDir = CurrentDir;
	OpenFileName.lpstrTitle = "*****  SELECT DESTINATION VOLUME ON SD CARD  *****";
	OpenFileName.nFileOffset = 0;
	OpenFileName.nFileExtension = 0;
	OpenFileName.lpstrDefExt = NULL;
	OpenFileName.lCustData = 0;
	OpenFileName.lpfnHook = NULL;
	OpenFileName.lpTemplateName = NULL;
	OpenFileName.Flags = OFN_EXPLORER;

	if (GetOpenFileName(&OpenFileName))
	{
		strcpy(file, szFile);
		return TRUE;
	}
	else
		return FALSE;
}