// vol2dsk.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Dennis D Hatton Sr

// Visual C++, Change project properties Charcter Set "not set"

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS	//Disable deprecation warnings
#endif
#include <stdio.h>			// defines FILENAME_MAX
#include <string.h>
#include <windows.h>		//Also enable Microsoft extensions (defines MAX_PATH)

BOOL OpenFileDialog(char*);
int ReplaceExt(char*, char*);
int ReplaceInvalidChar(char*);

int main(int argc, char* argv[])
{
	FILE* infile;
	FILE* outfile;
	int rtncode = 0;
	char* pch;
	unsigned int n, i, len;
	unsigned char buffer[256] = { 0 };	//Must be unsigned or (len int) will be signed
	char filename[MAX_PATH] = { 0 };
	char outfilename[MAX_PATH];

	printf("Convert TI Volume to DSK\n");
	printf("by Dennis Hatton 2019 \n\n");

	GetCurrentDirectory(MAX_PATH, outfilename);	//save current path

	if (argc != 2)	OpenFileDialog(filename);
	else			strcpy(filename, argv[1]);

	if ((infile = fopen(filename, "rb")) == NULL)	//rb read binary
	{
		printf("Could not open file: %s\n", filename);
		rtncode = 1;
	}
	else {
		fread(buffer, 1, 256, infile);		//binary use fread & frwite
		if (buffer[13] != 'D' || buffer[14] != 'S' || buffer[15] != 'K')
		{
			printf("File is not supported");
			rtncode = 1;
		}
		else {
			len = buffer[10] * 256;		//Size of disk (in sectors)
			len = buffer[11] + len;

			strncpy(filename, (const char*)buffer, 10);
			filename[11] = '\0';
			pch = strchr((char*)filename, ' ');
			if (pch == 0) n = 10;
			else n = pch - (char*)filename;
			filename[n] = '\0';				//Set end of string at last non space character
			strcat(filename, ".dsk");
			ReplaceInvalidChar(filename);	//Replace invalid characters with _

//			ReplaceExt(filename, (char *)".dsk");

			strcat(outfilename, "\\");
			strcat(outfilename, filename);
			printf("%s", outfilename);


			outfile = fopen(outfilename, "wb");
			fwrite(buffer, 1, 256, outfile);

			for (i = 0; i < (len - 1); i++)
			{
				fread(buffer, 1, 256, infile);
				fwrite(buffer, 1, 256, outfile);
			}
			fclose(outfile);
		}
	}
	fclose(infile);
//	if (rtncode)
//	{
		printf("\nPress any key to continue...\n");
		getchar();	//pause for key
//	}
	return rtncode;
}


/****************************************************************************/


BOOL OpenFileDialog(char* file)	//Function that will call dialog
{
	OPENFILENAME OpenFileName;
	char szFile[MAX_PATH];
	char CurrentDir[MAX_PATH];

	szFile[0] = 0;
	GetCurrentDirectory(MAX_PATH, CurrentDir);

	OpenFileName.lStructSize = sizeof(OPENFILENAME);
	OpenFileName.hwndOwner = NULL;
	OpenFileName.lpstrFilter = "TI Volume\0*.dsk\0All Files\0*.*\0";
	OpenFileName.lpstrCustomFilter = NULL;
	OpenFileName.nMaxCustFilter = 0;
	OpenFileName.nFilterIndex = 0;
	OpenFileName.lpstrFile = szFile;
	OpenFileName.nMaxFile = sizeof(szFile);
	OpenFileName.lpstrFileTitle = NULL;
	OpenFileName.nMaxFileTitle = 0;
	OpenFileName.lpstrInitialDir = CurrentDir;
	OpenFileName.lpstrTitle = "SELECT TI VOLUME";
	OpenFileName.nFileOffset = 0;
	OpenFileName.nFileExtension = 0;
	OpenFileName.lpstrDefExt = NULL;
	OpenFileName.lCustData = 0;
	OpenFileName.lpfnHook = NULL;
	OpenFileName.lpTemplateName = NULL;
	OpenFileName.Flags = OFN_EXPLORER;

	if (GetOpenFileName(&OpenFileName))
	{
		strcpy(file, szFile);
		return TRUE;
	}
	else
		return FALSE;
}
/****************************************************************************/

int ReplaceExt(char* szPath, char* szExt)	// Replace extension of filename
{
	char* pFile = strrchr(szPath, '/');
	pFile = pFile == NULL ? szPath : pFile + 1;
	char* pExt = strrchr(pFile, '.');
	if (pExt != NULL)
		strcpy(pExt, szExt);
	else
		strcat(pFile, szExt);
	return 0;
}

int ReplaceInvalidChar(char* filename)
{
	int j = 0;

	while (filename[j] != '\0')
	{	//invalid windows charcters /\:?*|�<>
		if (filename[j] == '/') filename[j] = '_';
		if (filename[j] == '\\') filename[j] = '_';
		if (filename[j] == ':') filename[j] = '_';
		if (filename[j] == '?') filename[j] = '_';
		if (filename[j] == '*') filename[j] = '_';
		if (filename[j] == '|') filename[j] = '_';	// | invalid in TI
		if (filename[j] == '\"') filename[j] = '_';	// " 34
		if (filename[j] == -108) filename[j] = '_';	// " is showing up as -108
		if (filename[j] == '<') filename[j] = '_';
		if (filename[j] == '>') filename[j] = '_';
		j++;
	}
	return 0;
}
