// FormatVolume.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Dennis D Hatton Sr


// TI_dsk2sd.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

// Visual C++, Change project properties Charcter Set "not set"
#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS	//Disable deprecation warnings
#endif
#include <stdio.h>
#include <string.h>
#include <windows.h>		//Also enable Microsoft extensions
BOOL OpenInputFileDialog(char*);
BOOL OpenOutputFileDialog(char*);

int main(int argc, char* argv[])
{
	FILE* fp;
	unsigned int i, dsksize;
	unsigned int c = 0;
	unsigned char buffer[512] = { 0 };
	char filename[MAX_PATH] = { 0 };

	printf("Quick format volume on SD card\n");
	printf("by Dennis Hatton 2020 \n\n");

	OpenInputFileDialog(filename);
	if ((fp = fopen(filename, "rb+")) == NULL) //rb+ read/write binary
	{
		printf("File not found: %s\n", filename);
		exit(1);
	}
	else
	{
		fseek(fp, 0, SEEK_SET);
		fread(buffer, 1, 512, fp);
		if (buffer[13] != 'D' || buffer[14] != 'S' || buffer[15] != 'K')
		{
			printf("Header does not contain D S K!\nProceed with disk formatting? (Y/N)N");
			c = getchar();
			if (c != 'Y' && c != 'y')exit(1);
		}
			printf("%s\n", filename);
			printf("\nFormat (1=90k 2=180k 3=360k 0=exit)?\n");
			while (c < '0' || c >'3')c = getchar();
			if (c == '0')exit(0);
			if (c == '1')dsksize = 0x168;
			if (c == '2')dsksize = 0x2D0;
			if (c == '3')dsksize = 0x5A0;

			buffer[10] = dsksize / 256;
			buffer[11] = dsksize % 256;
			buffer[12] = 0x09;
			buffer[13] = 'D';
			buffer[14] = 'S';
			buffer[15] = 'K';
			buffer[16] = ' ';

			if (dsksize == 0x5A0) buffer[17] = 80; else buffer[17] = 40;
			if (dsksize == 0x168) buffer[18] = 1; else buffer[18] = 2;
			buffer[19] = 0x01;
			for (i = 0x14; i < 256; i++) buffer[i] = 0; //Pad rest of TIsector 0 with 0s
			buffer[0x38] = 3; //mark sectors 0 & 1 used

			//Mark sectors unavailable per disk size
			if (dsksize == 0x168) i = 0x65;
			if (dsksize == 0x2D0) i = 0x92;
			if (dsksize == 0x5A0) i = 0xEC;
			for (i; i < 256; i++) buffer[i] = 0xFF;
			for (i = 0x100; i < 0x200; i++) buffer[i] = 0; //fill TIsector 1 with 0s

			fseek(fp, 0, SEEK_SET);
			fwrite(buffer, 1, 512, fp);

			for (i = 0; i < 512; i++)buffer[i] = 0xE5;
			for (i = 2; i < 0x2D1; i++)fwrite(buffer, 1, 512, fp);
	}
	fclose(fp);
	printf("\nPress any key to continue...\n");
	getchar();	//pause for key
	return 0;
}


/****************************************************************************/


BOOL OpenInputFileDialog(char* file)	//Function that will call dialog
{
	OPENFILENAME OpenFileName;
	char szFile[MAX_PATH];
	char CurrentDir[MAX_PATH];

	szFile[0] = 0;
	GetCurrentDirectory(MAX_PATH, CurrentDir);

	OpenFileName.lStructSize = sizeof(OPENFILENAME);
	OpenFileName.hwndOwner = NULL;
	OpenFileName.lpstrFilter = "DSK Files\0*.dsk\0 TIDisk Files\0*TIDisk\0 All Files\0*.*\0";
	OpenFileName.lpstrCustomFilter = NULL;
	OpenFileName.nMaxCustFilter = 0;
	OpenFileName.nFilterIndex = 0;
	OpenFileName.lpstrFile = szFile;
	OpenFileName.nMaxFile = sizeof(szFile);
	OpenFileName.lpstrFileTitle = NULL;
	OpenFileName.nMaxFileTitle = 0;
	OpenFileName.lpstrInitialDir = CurrentDir;
	OpenFileName.lpstrTitle = "*****  SELECT TI DSK IMAGE  *****";
	OpenFileName.nFileOffset = 0;
	OpenFileName.nFileExtension = 0;
	OpenFileName.lpstrDefExt = NULL;
	OpenFileName.lCustData = 0;
	OpenFileName.lpfnHook = NULL;
	OpenFileName.lpTemplateName = NULL;
	OpenFileName.Flags = OFN_EXPLORER;

	if (GetOpenFileName(&OpenFileName))
	{
		strcpy(file, szFile);
		return TRUE;
	}
	else
		return FALSE;
}

BOOL OpenOutputFileDialog(char* file)	//Function that will call dialog
{
	OPENFILENAME OpenFileName;
	char szFile[MAX_PATH];
	char CurrentDir[MAX_PATH];

	szFile[0] = 0;
	GetCurrentDirectory(MAX_PATH, CurrentDir);

	OpenFileName.lStructSize = sizeof(OPENFILENAME);
	OpenFileName.hwndOwner = NULL;
	OpenFileName.lpstrFilter = "DISKxxx Files\0DISK*.dbl\0 All Files\0*.*\0";
	OpenFileName.lpstrCustomFilter = NULL;
	OpenFileName.nMaxCustFilter = 0;
	OpenFileName.nFilterIndex = 0;
	OpenFileName.lpstrFile = szFile;
	OpenFileName.nMaxFile = sizeof(szFile);
	OpenFileName.lpstrFileTitle = NULL;
	OpenFileName.nMaxFileTitle = 0;
	OpenFileName.lpstrInitialDir = CurrentDir;
	OpenFileName.lpstrTitle = "*****  SELECT DISKxxx ON SD CARD  *****";
	OpenFileName.nFileOffset = 0;
	OpenFileName.nFileExtension = 0;
	OpenFileName.lpstrDefExt = NULL;
	OpenFileName.lCustData = 0;
	OpenFileName.lpfnHook = NULL;
	OpenFileName.lpTemplateName = NULL;
	OpenFileName.Flags = OFN_EXPLORER;

	if (GetOpenFileName(&OpenFileName))
	{
		strcpy(file, szFile);
		return TRUE;
	}
	else
		return FALSE;
}
